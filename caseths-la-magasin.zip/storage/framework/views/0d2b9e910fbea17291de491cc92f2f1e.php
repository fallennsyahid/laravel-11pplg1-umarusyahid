<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('asset-landing-page/css/create.css')); ?>">
</head>

<body>
    <form action="<?php echo e(route('about.update', $about)); ?>" method="POST" class="admin-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="title" class="form-label">Title:</label>
            <input type="text" id="title" name="title" class="form-input" value="<?php echo e($about->title); ?>">
        </div>

        <div>
            <label for="description" class="form-label">Description:</label>
            <textarea id="description" name="description" class="form-textarea"><?php echo e($about->description); ?></textarea>
        </div>

        <button type="submit" class="form-button">Update</button>
        <a href="<?php echo e(route('about.index')); ?>"><button type="button" class="form-button">Back</button></a>
    </form>

</body>

</html>
<?php /**PATH C:\laragon\www\laravel-11pplg1-umarusyahid\resources\views/admin/about/edit.blade.php ENDPATH**/ ?>