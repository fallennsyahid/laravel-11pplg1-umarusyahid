<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Admin - Portfolio</title>
    <link href="<?php echo e(asset('asset-landing-page/css/styles-admin.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('asset-landing-page/css/table.css')); ?>" rel="stylesheet" />
    <link href="//cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php if (isset($component)) { $__componentOriginal4eb1d04e08b5b091961d415111a15a66 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4eb1d04e08b5b091961d415111a15a66 = $attributes; } ?>
<?php $component = App\View\Components\NavbarAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NavbarAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4eb1d04e08b5b091961d415111a15a66)): ?>
<?php $attributes = $__attributesOriginal4eb1d04e08b5b091961d415111a15a66; ?>
<?php unset($__attributesOriginal4eb1d04e08b5b091961d415111a15a66); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4eb1d04e08b5b091961d415111a15a66)): ?>
<?php $component = $__componentOriginal4eb1d04e08b5b091961d415111a15a66; ?>
<?php unset($__componentOriginal4eb1d04e08b5b091961d415111a15a66); ?>
<?php endif; ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <a href="<?php echo e(route('portfolio.create')); ?>" style="margin: 1.25rem 0 0 1.25rem;">
                    <button class="delete-button">
                        <span>Add Portfolio</span>
                    </button>
                </a>
                <div class="body">
                    <div id="table-container" class="table-container">
                        <table class="modern-table" id="myTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Link</th>
                                    <th>Picture</th>
                                    <th>Detail</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($row->title); ?></td>
                                        <td><?php echo e($row->description); ?></td>
                                        <td><?php echo e($row->link); ?></td>
                                        <td>
                                            <?php if($row->picture): ?>
                                                <a href="<?php echo e(asset('storage/' . $row->picture)); ?>" target="_blank">
                                                    <button class="delete-button">
                                                        <span>View</span>
                                                    </button>
                                                </a>
                                            <?php else: ?>
                                                <p>Picture Not Available</p>
                                            <?php endif; ?>
                                        </td>
                                        <td align="center">
                                            <a href="<?php echo e(route('portfolio.show', $row->id)); ?>">
                                                <button class="delete-button"><span>Detail</span></button>
                                            </a>
                                        </td>
                                        <td align="center">
                                            <a href="<?php echo e(route('portfolio.edit', $row->id)); ?>">
                                                <button class="delete-button"><span>Update</span></button>
                                            </a>
                                        </td>
                                        <td align="center">
                                            <form action="<?php echo e(route('portfolio.destroy', $row->id)); ?>"
                                                id="delete-form-<?php echo e($row->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" data-id="<?php echo e($row->id); ?>"
                                                    class="delete-btn">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </main>
            <?php if (isset($component)) { $__componentOriginalba2734afff004ff527a44007b3505ae7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba2734afff004ff527a44007b3505ae7 = $attributes; } ?>
<?php $component = App\View\Components\FooterAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FooterAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba2734afff004ff527a44007b3505ae7)): ?>
<?php $attributes = $__attributesOriginalba2734afff004ff527a44007b3505ae7; ?>
<?php unset($__attributesOriginalba2734afff004ff527a44007b3505ae7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba2734afff004ff527a44007b3505ae7)): ?>
<?php $component = $__componentOriginalba2734afff004ff527a44007b3505ae7; ?>
<?php unset($__componentOriginalba2734afff004ff527a44007b3505ae7); ?>
<?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
    <script src="<?php echo e(asset('asset-landing-page/js/scripts-admin.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if (isset($component)) { $__componentOriginal9c8e73815168efeea949b2b9f7bded26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c8e73815168efeea949b2b9f7bded26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sweet-alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sweet-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c8e73815168efeea949b2b9f7bded26)): ?>
<?php $attributes = $__attributesOriginal9c8e73815168efeea949b2b9f7bded26; ?>
<?php unset($__attributesOriginal9c8e73815168efeea949b2b9f7bded26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c8e73815168efeea949b2b9f7bded26)): ?>
<?php $component = $__componentOriginal9c8e73815168efeea949b2b9f7bded26; ?>
<?php unset($__componentOriginal9c8e73815168efeea949b2b9f7bded26); ?>
<?php endif; ?>

    <script>
        let table = new DataTable('#myTable');
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel-11pplg1-umarusyahid\resources\views/admin/portfolio/index.blade.php ENDPATH**/ ?>