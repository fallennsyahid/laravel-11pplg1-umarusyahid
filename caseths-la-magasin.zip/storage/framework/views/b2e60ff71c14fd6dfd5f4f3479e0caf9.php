<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('asset-landing-page/css/create.css')); ?>">
</head>

<body>
    <form action="<?php echo e(route('certificate.update', $certificate->id)); ?>" method="POST" enctype="multipart/form-data"
        class="admin-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="title" class="form-label">Title:</label>
            <input type="text" id="title" name="title" class="form-input" value="<?php echo e($certificate->title); ?>">
        </div>

        <div>
            <label for="issued_by" class="form-label">Issued By:</label>
            <input type="text" id="issued_by" name="issued_by" class="form-input"
                value="<?php echo e($certificate->issued_by); ?>">
        </div>

        <div>
            <label for="description" class="form-label">Description:</label>
            <textarea id="description" name="description" class="form-textarea"><?php echo e($certificate->description); ?></textarea>
        </div>

        <div>
            <label for="date" class="form-label">Date:</label>
            <input type="date" name="date" id="date" class="form-input" value="<?php echo e($certificate->date); ?>">
        </div>

        <div>
            <label for="picture" class="form-label">Picture:</label>
            <input type="file" id="picture" name="picture" class="form-input">
            <img src="<?php echo e(asset('storage/' . $certificate->picture)); ?>" alt="<?php echo e($certificate->title); ?>" width="200px">
            <p>Current: <?php echo e($certificate->picture); ?></p>
        </div>

        <button type="submit" class="form-button">Update</button>
        <a href="<?php echo e(route('certificate.index')); ?>" class="form-button" style="text-decoration: none">Back To
            Home</a>
    </form>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel-11pplg1-umarusyahid\resources\views/admin/certificate/edit.blade.php ENDPATH**/ ?>