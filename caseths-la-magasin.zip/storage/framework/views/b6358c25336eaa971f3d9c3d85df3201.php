<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('asset-landing-page/css/create.css')); ?>">
</head>

<body>
    <form action="<?php echo e(route('skill.update', $skill->id)); ?>" method="POST" class="admin-form"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="title" class="form-label">Title:</label>
            <input type="text" id="title" name="title" class="form-input" value="<?php echo e($skill->title); ?>">
        </div>

        <div>
            <label for="photo" class="form-label">Picture:</label>
            <input type="file" id="photo" name="photo" class="form-input">
            <img src="<?php echo e(asset('storage/' . $skill->photo)); ?>" alt="<?php echo e($skill->title); ?>" width="100px">
            <p>Current: <?php echo e($skill->photo); ?></p>
        </div>

        <div>
            <label for="description" class="form-label">Description:</label>
            <textarea id="description" name="description" class="form-textarea"><?php echo e($skill->description); ?></textarea>
        </div>

        <button type="submit" class="form-button">Update</button>
    </form>

    <!-- Link Edit dengan ID yang benar -->
    <a href="<?php echo e(route('skill.index')); ?>" class="form-button" style="text-decoration: none">Back To About</a>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel-11pplg1-umarusyahid\resources\views/admin/skill/edit.blade.php ENDPATH**/ ?>