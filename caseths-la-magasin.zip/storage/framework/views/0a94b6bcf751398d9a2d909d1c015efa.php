<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Admin - Portfolio</title>
    <link href="<?php echo e(asset('asset-landing-page/css/styles-admin.css')); ?>" rel="stylesheet" />
    
    <link href="<?php echo e(asset('asset-landing-page/css/detail.css')); ?>" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php if (isset($component)) { $__componentOriginal4eb1d04e08b5b091961d415111a15a66 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4eb1d04e08b5b091961d415111a15a66 = $attributes; } ?>
<?php $component = App\View\Components\NavbarAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NavbarAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4eb1d04e08b5b091961d415111a15a66)): ?>
<?php $attributes = $__attributesOriginal4eb1d04e08b5b091961d415111a15a66; ?>
<?php unset($__attributesOriginal4eb1d04e08b5b091961d415111a15a66); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4eb1d04e08b5b091961d415111a15a66)): ?>
<?php $component = $__componentOriginal4eb1d04e08b5b091961d415111a15a66; ?>
<?php unset($__componentOriginal4eb1d04e08b5b091961d415111a15a66); ?>
<?php endif; ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="table-position">
                    <div class="table-container">
                        <h1>Detail Data</h1>
                        <p><span>Title:</span> <?php echo e($portfolio->title); ?></p>
                        <p><span>Description:</span> <?php echo e($portfolio->description); ?></p>

                        <h3>Picture Detail</h3>
                        <img src="<?php echo e(asset('storage/' . $portfolio->picture)); ?>" alt="<?php echo e($portfolio->title); ?>"
                            width="100%">
                    </div>
                </div>
                <a href="<?php echo e(route('portfolio.index')); ?>" class="back-btn"><button type="button"
                        class="btn btn-danger">Back</button></a>
            </main>
            <?php if (isset($component)) { $__componentOriginalba2734afff004ff527a44007b3505ae7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba2734afff004ff527a44007b3505ae7 = $attributes; } ?>
<?php $component = App\View\Components\FooterAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FooterAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba2734afff004ff527a44007b3505ae7)): ?>
<?php $attributes = $__attributesOriginalba2734afff004ff527a44007b3505ae7; ?>
<?php unset($__attributesOriginalba2734afff004ff527a44007b3505ae7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba2734afff004ff527a44007b3505ae7)): ?>
<?php $component = $__componentOriginalba2734afff004ff527a44007b3505ae7; ?>
<?php unset($__componentOriginalba2734afff004ff527a44007b3505ae7); ?>
<?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('asset-landing-page/js/scripts-admin.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel-11pplg1-umarusyahid\resources\views/admin/portfolio/show.blade.php ENDPATH**/ ?>